k5_v4.00.01_flashable.bin
从（UV-5R PLUS）中备份出来的
提示音仅支持英文，其它未发现跟官方.26版本有明显不同。

0##k5_v2.01.26_MODDED3.bin    **推荐刷入**
不支持中文
支持不限时扫频
支持18-1300Mhz频段
支持0.5k/1k步进
支持航空频段禁止发射
支持S表，显示信号强度
支持显示电池电压
支持发射时显示Mic信号强度
支持ABR屏幕背光最长持续8秒

1##uv_k5_01_26_cold_messenger_encoded.bin
支持T9打字的AFSK信使。
要启用信使视图，请按闪光灯按钮
使用键盘入消息
按菜单键发送消息
按退出键以清除消息
在没有输入消息的情况下按 EXIT 退出信使视图
如果要键入同一按键上的多个字母，请使用星号 （*） 确认所选字符

2##uv_k5_01_26_spectrum_2MHz_encoded.bin
频谱扫描仪。
要启用 Spectum 视图，请按闪光灯按钮
按住向上或向下键可更改中心频率
按 8 / 2 放大/缩小
按 1 / 7 增加/降低分辨率（较小的分辨率 == 更快的更新速率）
按 PTT 或退出以禁用频谱视图

3##uv_k5_01_26_rssi_sbar_encoded.bin
带校准 S 步长

4##uv_k5_01_26_rssi_printer_encoded.bin
显示数字格式 RX 信号电平 （RSSI），包括小信号电平图表。

5##uv_k5_01_26_pong_game_encoded.bin
乒乓球游戏

6##k5_v3.00.10_flashable.bin
支持中文固件

7##k5_V3.00.10_encrypted_18to1300MHz.bin    **推荐刷入**
中文固件扩频至短波

8##k5_26_encrypted_18to1300MHz.bin
官方26版固件扩频至短波